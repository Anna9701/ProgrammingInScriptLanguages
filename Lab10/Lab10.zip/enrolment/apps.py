from django.apps import AppConfig


class EnrolmentConfig(AppConfig):
    name = 'enrolment'
